-- AlterTable
ALTER TABLE `user` ADD COLUMN `lastActive` DATETIME(3) NULL;
